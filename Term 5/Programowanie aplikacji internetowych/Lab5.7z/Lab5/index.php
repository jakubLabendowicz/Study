<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body> 

   
        <?php
        include 'klasy/User.php';
        include 'klasy/RegistrationForm.php';
      //  $user1 = new User ('kp', 'Kubus Puchatek','kubus@stumilowylas.pl', 'nielubietygryska');
      //  $user1 -> show();
        
        $rf = new RegistrationForm(); //wyświetla formularz rejestracji

       
        
        if (filter_input(INPUT_POST, 'submit',
       FILTER_SANITIZE_FULL_SPECIAL_CHARS)) {
        $user = $rf->checkUser(); //sprawdza poprawność danych
        if ($user === NULL)
        echo "<p>Niepoprawne dane rejestracji.</p>";
        else{
        echo "<p>Poprawne dane rejestracji:</p>";
        $user->show();
        User::getAllUsers();
        $user->save("user.json");
        
        }
        }
    
        ?>    
    </body>
</html>
