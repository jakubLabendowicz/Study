//
//  ContentView.swift
//  jl_2022_03_17_lab3_zad2
//
//  Created by student on 17/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    enum Rozmiary: String, CaseIterable, Identifiable {
        case one
        case two
        case three
        
        var id: String {self.rawValue}
    }
    
    enum Firmy: String, CaseIterable, Identifiable {
        case one
        case two
        case three
        
        var id: String {self.rawValue}
    }
    
    
    @State var wybranyRozmiar: Rozmiary = .one
    @State var wybranaFirma:Firmy = .one
    @State var wybranaLiczbaOpon:String = "0"
    @State var stan = [
        (firma: Firmy.one, rozmiar: Rozmiary.one, ilosc: 10),
        (firma: Firmy.one, rozmiar: Rozmiary.two, ilosc: 20),
        (firma: Firmy.one, rozmiar: Rozmiary.three, ilosc: 5),
        (firma: Firmy.two, rozmiar: Rozmiary.one, ilosc: 10),
        (firma: Firmy.two, rozmiar: Rozmiary.two, ilosc: 20),
        (firma: Firmy.two, rozmiar: Rozmiary.three, ilosc: 5),
        (firma: Firmy.three, rozmiar: Rozmiary.one, ilosc: 10),
        (firma: Firmy.three, rozmiar: Rozmiary.two, ilosc: 20),
        (firma: Firmy.three, rozmiar: Rozmiary.three, ilosc: 5),
    ]
    var body: some View {
        VStack {
            Text("Rozmiar")
            Picker(selection: $wybranyRozmiar, label: Text("Rozmiar"), content: {
                ForEach(Rozmiary.allCases) {
                    rozmiar in Text(rozmiar.rawValue.capitalized).tag(rozmiar)
                }
            })
            .padding()
            .pickerStyle(SegmentedPickerStyle())
            
            Text("Firma")
            Picker(selection: $wybranaFirma, label: Text("Firma"), content: {
                ForEach(Firmy.allCases) {
                    firma in Text(firma.rawValue.capitalized).tag(firma)
                }
            })
            .padding()
            .pickerStyle(SegmentedPickerStyle())
            Text("Ilość")
            TextField("Ilość", text: $wybranaLiczbaOpon)
            .padding()
            Button(action: {
                for i in self.stan {
                    if i.firma == self.wybranaFirma || i.rozmiar == self.wybranyRozmiar {
                        if i.ilosc > (self.$wybranaLiczbaOpon) {
                            print("Tak")
                        }
                    }
                }
            }, label: {Text("Sprawdź")})
        }
    }
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(wybranyRozmiar: .one, wybranaFirma: .one, wybranaLiczbaOpon: "0")
    }
}
