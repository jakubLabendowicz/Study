//
//  CaffeView.swift
//  jl_2022_04_07_lab6zad2
//
//  Created by student on 07/04/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct CaffeView: View {
    @Binding var caffe: String
    @Environment (\.presentationMode) var presentationMode
    var body: some View {
        VStack {
            Picker("Select caffe", selection: $caffe) {
                Text("None").tag("None")
                Image(systemName: "pencil").tag("Flat White")
                Image(systemName: "pencil").tag("Espresso")
                Image(systemName: "pencil").tag("Double Espresso")
                Image(systemName: "pencil").tag("Cappuccino")
            }
            Button("Close") {
                self.presentationMode.wrappedValue.dismiss()
            }
        }
    }
}

struct CaffeView_Previews: PreviewProvider {
    static var previews: some View {
        CaffeView(caffe: .constant("None"))
    }
}
