//
//  ContentView.swift
//  jl_2022_04_07_lab6zad2
//
//  Created by student on 07/04/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var showJuiceModal: Bool = false
    @State private var showCaffeModal: Bool = false
    @State var juice:String = "None"
    @State var caffe:String = "None"
    
    var body: some View {
        VStack{
            Text(juice)
            Text(caffe)
            
            Button(action: {
                self.showJuiceModal.toggle()
            }, label: {
                Text("Select Juice")
            })
                .sheet(isPresented: $showJuiceModal) {
                    JuiceView(juice: self.$juice)
            }
            
            Button(action: {
                self.showCaffeModal.toggle()
            }, label: {
                Text("Select Caffe")
            })
                .sheet(isPresented: $showCaffeModal) {
                    CaffeView(caffe: self.$caffe)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
