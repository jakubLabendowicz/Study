//
//  ContentView.swift
//  jl_2022_03_10_lab2
//
//  Created by student on 10/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//



import SwiftUI

struct ContentView: View {
    var tablica_kolorow = [Color.red, Color.orange, Color.yellow, Color.green, Color.blue, Color.purple]
    
    var body: some View {
        ZStack
        {
            ForEach(0..<tablica_kolorow.count)
            {
                Rectangle()
                    .fill(self.tablica_kolorow[$0])
                    .frame(width: 200, height: 200)
                    .offset(x: CGFloat($0) * 10.0,y: CGFloat($0) * 10.0)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
