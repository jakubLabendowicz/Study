//
//  Gatunek+CoreDataProperties.swift
//  jl_2022_05_26_lab12_zad2
//
//  Created by student on 26/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData


extension Gatunek {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Gatunek> {
        return NSFetchRequest<Gatunek>(entityName: "Gatunek")
    }

    @NSManaged public var nazwa: String?
    @NSManaged public var ksiazka: NSSet?

}

// MARK: Generated accessors for ksiazka
extension Gatunek {

    @objc(addKsiazkaObject:)
    @NSManaged public func addToKsiazka(_ value: Ksiazka)

    @objc(removeKsiazkaObject:)
    @NSManaged public func removeFromKsiazka(_ value: Ksiazka)

    @objc(addKsiazka:)
    @NSManaged public func addToKsiazka(_ values: NSSet)

    @objc(removeKsiazka:)
    @NSManaged public func removeFromKsiazka(_ values: NSSet)

}

extension Gatunek : Identifiable {
    
}
