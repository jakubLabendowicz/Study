//
//  Ksiazka+CoreDataClass.swift
//  jl_2022_05_26_lab12_zad2
//
//  Created by student on 26/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Ksiazka)
public class Ksiazka: NSManagedObject {

}
