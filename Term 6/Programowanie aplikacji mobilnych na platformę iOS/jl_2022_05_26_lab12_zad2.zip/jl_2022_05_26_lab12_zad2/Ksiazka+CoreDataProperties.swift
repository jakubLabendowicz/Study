//
//  Ksiazka+CoreDataProperties.swift
//  jl_2022_05_26_lab12_zad2
//
//  Created by student on 26/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData


extension Ksiazka {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Ksiazka> {
        return NSFetchRequest<Ksiazka>(entityName: "Ksiazka")
    }

    @NSManaged public var autor: String?
    @NSManaged public var tytul: String?
    @NSManaged public var rok_wydania: Int16
    @NSManaged public var wydawnictwo: String?
    @NSManaged public var ocena: Int16
    @NSManaged public var gatunek: Gatunek?

}

extension Ksiazka : Identifiable {
    
}
