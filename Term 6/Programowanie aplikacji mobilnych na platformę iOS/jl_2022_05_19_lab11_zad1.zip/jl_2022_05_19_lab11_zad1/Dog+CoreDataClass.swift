//
//  Dog+CoreDataClass.swift
//  jl_2022_05_19_lab11_zad1
//
//  Created by student on 19/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData


public class Dog: NSManagedObject {

}
