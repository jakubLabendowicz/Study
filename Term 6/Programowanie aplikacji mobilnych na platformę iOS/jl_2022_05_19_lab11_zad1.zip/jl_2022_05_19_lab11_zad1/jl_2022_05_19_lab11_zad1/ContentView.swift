//
//  ContentView.swift
//  Lab11_K
//
//  Created by student on 19/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    @State private var name: String = ""
    @State private var year: String = ""
    @State private var search: String = ""
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Dog.name, ascending: true)],
                  animation: .default)
    
    private var dogs: FetchedResults<Dog>
    
    var body: some View {
        VStack{
            TextField("Imie", text: $name)
            TextField("Year", text: $year)
            Button("Dodaj psa"){
                self.addDog()
            }
            
            List{
                ForEach(dogs){
                    dog in
                    Text("\(dog.name!) - year\(dog.yearBirth)")
                }
                .onDelete(perform: self.deleteDog)
            }
        }
    }
    
    private func addDog(){
        let newDog = Dog(context: viewContext)
        newDog.name = name
        newDog.yearBirth = Int16(year)!
        
        do{
            try viewContext.save()
        }catch{
            let error = error as NSError
            fatalError("Error :\(error)")
        }
    }
    
    private func deleteDog(offsets: IndexSet){
        
        withAnimation{
            offsets.map{dogs[$0]}.forEach(viewContext.delete)
            do{
                try viewContext.save()
            }catch{
                let error = error as NSError
                fatalError("Error :\(error)")
            }
        }
    }
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
