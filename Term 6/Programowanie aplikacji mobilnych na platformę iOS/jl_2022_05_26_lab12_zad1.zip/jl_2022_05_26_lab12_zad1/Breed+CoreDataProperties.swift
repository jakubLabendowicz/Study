//
//  Breed+CoreDataProperties.swift
//  jl_2022_05_19_lab11_zad1
//
//  Created by student on 26/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData


extension Breed {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Breed> {
        return NSFetchRequest<Breed>(entityName: "Breed")
    }

    @NSManaged public var name: String?
    @NSManaged public var dog: NSSet?

}

// MARK: Generated accessors for dog
extension Breed {

    @objc(addDogObject:)
    @NSManaged public func addToDog(_ value: Dog)

    @objc(removeDogObject:)
    @NSManaged public func removeFromDog(_ value: Dog)

    @objc(addDog:)
    @NSManaged public func addToDog(_ values: NSSet)

    @objc(removeDog:)
    @NSManaged public func removeFromDog(_ values: NSSet)

}
