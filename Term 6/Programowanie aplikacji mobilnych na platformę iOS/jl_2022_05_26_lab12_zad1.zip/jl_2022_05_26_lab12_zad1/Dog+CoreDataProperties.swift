//
//  Dog+CoreDataProperties.swift
//  jl_2022_05_19_lab11_zad1
//
//  Created by student on 26/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData


extension Dog {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Dog> {
        return NSFetchRequest<Dog>(entityName: "Dog")
    }

    @NSManaged public var name: String?
    @NSManaged public var yearBirth: Int16
    @NSManaged public var breed: Breed?

}
