//
//  Breed+CoreDataClass.swift
//  Lab12
//
//  Created by student on 26/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData


public class Breed: NSManagedObject {

}
