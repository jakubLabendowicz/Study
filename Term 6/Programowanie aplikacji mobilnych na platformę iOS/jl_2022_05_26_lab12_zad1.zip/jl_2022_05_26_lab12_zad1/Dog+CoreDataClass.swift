//
//  Dog+CoreDataClass.swift
//  Lab11_K
//
//  Created by student on 19/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Dog)
public class Dog: NSManagedObject {

}
