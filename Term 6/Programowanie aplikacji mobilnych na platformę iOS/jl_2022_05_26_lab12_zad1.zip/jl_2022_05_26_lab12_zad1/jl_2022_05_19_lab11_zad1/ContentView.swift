//
//  ContentView.swift
//  Lab12
//
//  Created by student on 26/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
     @State private var name: String = ""
     @State private var year: String = ""
     @State private var search: String = ""
       
       @Environment(\.managedObjectContext) private var viewContext
       
       @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Dog.name, ascending: true)],
                     animation: .default)
    
    private var dogs: FetchedResults<Dog>
    
       @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Breed.name, ascending: true)],
                      animation: .default)

    
       private var breeds: FetchedResults<Breed>
    
      @State private var selectedBreed: Breed?
       
       var body: some View {
           VStack{
               Text("Psy")
               TextField("Imie", text: $name)
               TextField("Year", text: $year)
            
            var newDog = Dog(context: self.viewContext)
            newDog.name = "Azor"
            newDog.yearBirth = 2
        
            do{
                          try viewContext.save()
                      }catch{
                          let error = error as NSError
                          fatalError("Error :\(error)")
                      }
            
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error\(nsError),\(nsError.userInfo)")
             }
            
            Picker(selection: $selectedBreed, label: Text("Wybierz")){
                ForEach(breeds, id: \.self){
                    (breed: Breed) in
                    Text(breed.name!).tag(breed as Breed?)
                }
            }
            
            if(breeds.count == 0){
                Button(action: addBreeds){
                    Text("Add breeds")
                }
            }
            
               Button("Dodaj psa"){
                   self.addDog()
               }
               
               List{
                   ForEach(dogs){
                       dog in
                    Text("\(dog.name!) - \(dog.age) years old - \(dog.breed!.name!)")
                   }
                   .onDelete(perform: self.deleteDog)
               }
           }
       }
       
       private func addDog(){
           let newDog = Dog(context: viewContext)
           newDog.name = name
           newDog.yearBirth = Int16(year)!
           newDog.breed = selectedBreed
        
           do{
               try viewContext.save()
           }catch{
               let error = error as NSError
               fatalError("Error :\(error)")
           }
       }
       
       private func deleteDog(offsets: IndexSet){
           
           withAnimation{
               offsets.map{dogs[$0]}.forEach(viewContext.delete)
               do{
                   try viewContext.save()
               }catch{
                   let error = error as NSError
                   fatalError("Error :\(error)")
               }
           }
       }
    
    private func addBreeds(){
        var newBreed = Breed(context: viewContext)
        newBreed.name = "owczarek niemiecki"
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error\(nsError),\(nsError.userInfo)")
         }

         newBreed = Breed(context: viewContext)
         newBreed.name = "husky"
         do {
            try viewContext.save()
         } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError),\(nsError.userInfo)")
         }
        }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
