//
//  PanelView.swift
//  jl_2022_03_17_lab3
//
//  Created by student on 17/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct PanelView: View {
    @Binding var ileRazy : Int
    var body: some View {
        Button(action: {self.ileRazy = self.ileRazy + 1}) {
        Text("Wciśnij")
            .fontWeight(.bold)
            .font(.title)
            .padding()
            .background(Color.green)
            .cornerRadius(35)
            .foregroundColor(.blue)
            .padding(10)
            .overlay(
                RoundedRectangle(cornerRadius:35)
                    .stroke(Color.purple, lineWidth: 5)
            )
        }
    }
}

struct PanelView_Previews: PreviewProvider {
    static var previews: some View {
        PanelView(ileRazy: .constant(0))
    }
}
