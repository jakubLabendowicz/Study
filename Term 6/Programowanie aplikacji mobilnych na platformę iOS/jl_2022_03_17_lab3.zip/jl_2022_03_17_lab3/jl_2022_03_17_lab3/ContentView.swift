//
//  ContentView.swift
//  jl_2022_03_17_lab3
//
//  Created by student on 17/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var ileRazy : Int = 0
    var body: some View {
        VStack{
            Text("Wciśnij przycisk")
            PanelView(ileRazy: $ileRazy)
            Text("Wciśnięto \(ileRazy) razy")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
