//
//  ContentView.swift
//  jl_2022_05_05_lab9_zad1
//
//  Created by student on 05/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var imagesList = ["Dog1", "Dog2", "Dog3"]
    var minIndex = 0
    var maxIndex = 2
    @State var index: Int = 0
    @State var showLabel = false
    
    var body: some View {
        VStack{
            Image(imagesList[self.index])
            .gesture(TapGesture().onEnded(){
                if(self.index != self.maxIndex) {
                    self.index = self.index + 1
                } else {
                    self.index = self.minIndex
                }
                self.showLabel = false
            })
            .gesture(LongPressGesture().onEnded(){_ in
                self.showLabel = !self.showLabel
            })
            Text(showLabel ? imagesList[self.index]: "")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(index: 0)
    }
}
