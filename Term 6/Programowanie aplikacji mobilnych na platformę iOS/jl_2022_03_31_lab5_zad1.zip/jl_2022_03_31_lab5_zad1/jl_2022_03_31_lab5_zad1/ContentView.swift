//
//  ContentView.swift
//  jl_2022_03_31_lab5_zad1
//
//  Created by student on 31/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack{
                ZStack{
                    Rectangle()
                    .frame(width: 300, height: 300)
                    .foregroundColor(Color.yellow)
                    Circle()
                        .frame(width: 300, height: 300)
                        .foregroundColor(Color.red)
                    Text("Mix")
                        .foregroundColor(.black)
                        .font(.system(size:50, weight: .bold))
                }
                List{
                    NavigationLink(
                        destination: RectangleView(),
                        label: {
                            Text("Rectangle")
                                .frame(width: 200, height: 40)
                                .background(Color.yellow)
                        }
                    )
                    NavigationLink(
                        destination: CircleView(),
                        label: {
                            Text("Circle")
                                .frame(width: 200, height: 40)
                                .background(Color.yellow)
                        }
                    )
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
