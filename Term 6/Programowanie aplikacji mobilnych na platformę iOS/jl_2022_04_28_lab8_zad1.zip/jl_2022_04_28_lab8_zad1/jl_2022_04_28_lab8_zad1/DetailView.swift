//
//  DetailView.swift
//  jl_2022_04_28_lab8_zad1
//
//  Created by student on 28/04/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct DetailView: View {
    @State var event: Event
    @State var duration: Int = 0
    var body: some View {
        VStack {
            Text(event.name)
            Text(String(event.duration))
//            Slider(value: $duration, in: 0...60, step: 5)
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(event: Event(name: "", duration: 0))
    }
}
