//
//  ContentView.swift
//  jl_2022_04_28_lab8_zad1
//
//  Created by student on 28/04/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI
struct Event{
    let name: String
    let duration: Int
}

struct ContentView: View {
    @State var events = [
        Event(name: "Event 1", duration: 150),
        Event(name: "Event 2", duration: 210),
        Event(name: "Event 3", duration: 120)
    ]
    
    var body: some View {
        NavigationView {
            List {
                ForEach(events, id: \.name) { event in
                    HStack {
                        Image(systemName: "pencil")
                        VStack {
                            Text(event.name)
                            Text(String(event.duration))
                        }
                        NavigationLink(destination: DetailView(event: event), label: {Text("")})
                    }
                }
            }
        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
