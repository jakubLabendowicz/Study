//
//  ContentView.swift
//  jl_2022_03_24_lab4_zad1
//
//  Created by student on 24/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

func PLNnaEUR(kwota: Double) -> Double {
    return kwota*4.6
}
func EURnaPLN(kwota: Double) -> Double{
    return kwota*0.21
}

struct ContentView: View {
    enum Currency: String, CaseIterable, Identifiable {
        case PLN
        case USD
        case EURO
        
        var id: String {self.rawValue}
    }
    
    var table = [[Currency.USD, 1], [Currency.PLN, 2], [Currency.EURO, 3]]
    
    
    @State var inCurrency:Currency = .PLN
    @State var outCurrency:Currency = .USD
    @State var quantity:Double = 0
    @State var value:Double = 0
    
    var body: some View {
        VStack{
            VStack{
                Text("Kantor").bold()
                Text("Godziny otwarcia: ...")
            }.padding()
            
            VStack{
                Text("Kupowana waluta")
                Picker(selection: $inCurrency, label: Text(""), content: {
                    ForEach(Currency.allCases) {
                        currency in Text(currency.rawValue.capitalized).tag(currency)
                    }
                })
                .pickerStyle(SegmentedPickerStyle())
            }.padding()
            
            VStack{
                Text("Sprzedawana waluta")
                Picker(selection: $outCurrency, label: Text(""), content: {
                    ForEach(Currency.allCases) {
                        currency in Text(currency.rawValue.capitalized).tag(currency)
                    }
                })
                .pickerStyle(SegmentedPickerStyle())
            }.padding()
            
            VStack{
                Text("Wartość kupowanej waluty")
                TextField("Wartość kupowanej waluty", text: Binding(
                    get:{String(self.quantity)},
                    set:{self.quantity = Double($0) ?? 0}
                ))
            }.padding()
            
            Text("").position()
            
            VStack{
                Button(action: {
                  if self.inCurrency == .PLN && self.outCurrency == .EURO{
                    self.value = PLNnaEUR(kwota: Double(self.quantity))
                }
                    else if self.inCurrency == .EURO && self.outCurrency == .PLN{
                        self.value = EURnaPLN(kwota: Double(self.quantity))
                    }
                }) {
                    Text("Konwertuj")
                }
            }.padding()
            
            VStack{
                Text("Wartość sprzedawanej waluty")
                Text("\(self.value)")
            }.padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(inCurrency: .PLN, outCurrency: .USD, quantity: 0)
    }
}
