//
//  Car+CoreDataProperties.swift
//  jl_2022_05_19_lab11_zad2
//
//  Created by student on 19/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//
//

import Foundation
import CoreData


extension Car {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Car> {
        return NSFetchRequest<Car>(entityName: "Car")
    }

    @NSManaged public var brand: String?
    @NSManaged public var model: String?
    @NSManaged public var prod_year: Int32
    @NSManaged public var mileage: Int32
    @NSManaged public var price: Double

}

extension Car : Identifiable {
    
}
