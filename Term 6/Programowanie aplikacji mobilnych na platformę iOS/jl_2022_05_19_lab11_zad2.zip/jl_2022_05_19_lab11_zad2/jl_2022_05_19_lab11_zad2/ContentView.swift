//
//  ContentView.swift
//  Lab11_K1
//
//  Created by student on 19/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    @State private var price: String = ""
    @State private var brand: String = ""
    @State private var model: String = ""
    @State private var prod_year: String = ""
    @State private var mileage: String = ""
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Car.brand, ascending: true)],
    animation: .default)
    
    private var cars: FetchedResults<Car>
    
    var body: some View {
        VStack{
            
            TextField("Marka", text: $brand).padding()
            TextField("Model", text: $model).padding()
            TextField("Rok produkcji", text: $prod_year).padding()
            TextField("Przebieg", text: $mileage).padding()
            TextField("Cena", text: $price).padding()
            
            Button("Dodaj auto"){
                self.addCar()
            }
            
            List{
                ForEach(cars){
                    car in
                    HStack{
                        Text("\(car.brand!) \(car.model!) \(car.prod_year) \(car.mileage) \(car.price)")
                        Button(action: {
                            print("Delete button tapped!")
                        }) {
                            Image(systemName: "trash")
                        }
                    }
                }
                .onDelete(perform: self.deleteCar)
            }
            
        }
    }
    
    private func addCar(){
        let newCar = Car(context: viewContext)
        newCar.brand = brand
        newCar.model = model
        newCar.prod_year = Int32(prod_year)!
        newCar.mileage = Int32(mileage)!
        newCar.price = Double(price)!
        
        do{
            try viewContext.save()
        }catch{
            let error = error as NSError
            fatalError("Error :\(error)")
        }
        
    }
    
    private func deleteCar(offsets: IndexSet){
        withAnimation{
            offsets.map{cars[$0]}.forEach(viewContext.delete)
            do{
                try viewContext.save()
            }catch{
                let error = error as NSError
                fatalError("Error :\(error)")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
