//
//  ContentView.swift
//  jl_2022_03_31_lab5_zad2
//
//  Created by student on 31/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack{
                List{
                    NavigationLink(
                        destination: Car1View(),
                        label: {
                            Text("Marka 1")
                                .frame(width: 200, height: 40)
                                .background(Color.red)
                        }
                    )
                    NavigationLink(
                        destination: Car2View(),
                        label: {
                            Text("Marka 2")
                                .frame(width: 200, height: 40)
                                .background(Color.green)
                        }
                    )
                    NavigationLink(
                        destination: Car3View(),
                        label: {
                            Text("Marka 3")
                                .frame(width: 200, height: 40)
                                .background(Color.blue)
                        }
                    )
                }
            }
        .navigationBarTitle("Marki samochodów")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
