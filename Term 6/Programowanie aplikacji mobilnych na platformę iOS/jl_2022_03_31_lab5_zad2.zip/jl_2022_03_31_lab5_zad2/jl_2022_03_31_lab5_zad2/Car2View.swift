//
//  Car2View.swift
//  jl_2022_03_31_lab5_zad2
//
//  Created by student on 31/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct Car2View: View {
    var body: some View {
        VStack{
            ZStack{
                Rectangle()
                    .frame(width: 300, height: 300)
                    .foregroundColor(Color.green)
                Text("Marka 2")
                    .foregroundColor(.black)
                    .font(.system(size:50, weight: .bold))
            }
        }
    .navigationBarTitle("Marka 2")
    }
}

struct Car2View_Previews: PreviewProvider {
    static var previews: some View {
        Car2View()
    }
}
