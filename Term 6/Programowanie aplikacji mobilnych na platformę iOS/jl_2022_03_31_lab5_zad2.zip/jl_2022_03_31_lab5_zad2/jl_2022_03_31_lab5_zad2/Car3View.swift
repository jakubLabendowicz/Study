//
//  Car3View.swift
//  jl_2022_03_31_lab5_zad2
//
//  Created by student on 31/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct Car3View: View {
    var body: some View {
        VStack{
            ZStack{
                Rectangle()
                    .frame(width: 300, height: 300)
                    .foregroundColor(Color.blue)
                Text("Marka 3")
                    .foregroundColor(.black)
                    .font(.system(size:50, weight: .bold))
            }
        }
    .navigationBarTitle("Marka 3")
    }
}

struct Car3View_Previews: PreviewProvider {
    static var previews: some View {
        Car3View()
    }
}
