//
//  Car1View.swift
//  jl_2022_03_31_lab5_zad2
//
//  Created by student on 31/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct Car1View: View {
    var body: some View {
        VStack{
            ZStack{
                Rectangle()
                    .frame(width: 300, height: 300)
                    .foregroundColor(Color.red)
                Text("Marka 1")
                    .foregroundColor(.black)
                    .font(.system(size:50, weight: .bold))
            }
        .navigationBarTitle("Marka 1")
        }
    }
}

struct Car1View_Previews: PreviewProvider {
    static var previews: some View {
        Car1View()
    }
}
