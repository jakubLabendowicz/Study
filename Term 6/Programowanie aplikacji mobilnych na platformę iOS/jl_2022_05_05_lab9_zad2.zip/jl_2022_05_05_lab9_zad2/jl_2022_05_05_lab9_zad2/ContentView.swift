//
//  ContentView.swift
//  jl_2022_05_05_lab9_zad2
//
//  Created by student on 05/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @GestureState var isLong = false
    var body: some View {
        let longPress = LongPressGesture()
            .updating($isLong){
                value,state, transation in
                state = value
        }
        
        return Text("Colored text").foregroundColor(isLong ? .red : .green)
            .gesture(longPress)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
