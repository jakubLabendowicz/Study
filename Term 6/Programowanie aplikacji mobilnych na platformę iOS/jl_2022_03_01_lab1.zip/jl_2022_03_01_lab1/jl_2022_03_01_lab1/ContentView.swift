//
//  ContentView.swift
//  jl_2022_03_01_lab1
//
//  Created by student on 03/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var dzien: String = ""
    @State var dzienwybor: String = ""
    @State var showingAlert = false
    var body: some View {
        VStack (alignment: .center){
            Text("Podaj wybrany dzien tygodnia").background(Color.green).rotation3DEffect(.degrees(45), axis: (x: 1, y: 0, z: 0))
            
            TextField("Wpisz dzien tygodnia", text: $dzien)
            
            Button(action: {
                if (self.dzien == "Poniedzialek" || self.dzien == "Wtorek" || self.dzien == "Sroda" || self.dzien == "Czwartek" || self.dzien == "Piatek" || self.dzien == "Sobota" || self.dzien == "Niedziela") {
                    self.dzienwybor = self.dzien
                } else {
                    self.showingAlert = true
                }
            }, label: {Text("Zatwierdz wybor")}).background(Color.yellow)
            
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Title"), message: Text("Wiadomosc"))
            }
            
            Text("Wybrano: \(dzienwybor)")
        }.padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
