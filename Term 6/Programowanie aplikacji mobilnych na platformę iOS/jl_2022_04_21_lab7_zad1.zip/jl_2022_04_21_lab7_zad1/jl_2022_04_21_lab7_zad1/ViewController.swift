//
//  ViewController.swift
//  jl_2022_04_21_lab7_zad1
//
//  Created by student on 21/04/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myTableView: UITableView!
    var domy = [["Warszawa", "123", "5", "321", "2", "dom1"], ["Lublin", "123", "5", "321", "2", "dom2"], ["Wrocław", "123", "5", "321", "2", "dom3"], ["Poznań", "123", "5", "321", "2", "dom4"]]
    var mieszkania = [["Gdańsk", "56", "5", "tak", "mieszkanie"], ["Szczecin", "56", "5", "tak", "mieszkanie"]]

    override func viewDidLoad() {
        super.viewDidLoad()
        myTableView.delegate = self
        myTableView.dataSource = self
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        print("row of table view")
    }
}

extension ViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0) {
            return domy.count
        } else {
            return mieszkania.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0) {
            return "Domy"
        } else {
            return "Mieszkania"
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if(indexPath.section == 0) {
            cell.textLabel?.text = domy[indexPath.row][0]
            cell.imageView?.image = UIImage(named: domy[indexPath.row][5])
            cell.detailTextLabel?.text = domy[indexPath.row][1]
        } else {
            cell.textLabel?.text = mieszkania[indexPath.row][0]
            cell.imageView?.image = UIImage(named: mieszkania[indexPath.row][4])
            cell.detailTextLabel?.text = mieszkania[indexPath.row][1]
        }
        return cell
    }
}
