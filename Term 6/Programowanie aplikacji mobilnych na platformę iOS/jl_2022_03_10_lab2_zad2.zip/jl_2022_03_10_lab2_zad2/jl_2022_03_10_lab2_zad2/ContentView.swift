//
//  ContentView.swift
//  jl_2022_03_10_lab2_zad2
//
//  Created by student on 10/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack(alignment: .bottom){
            Image("kotek")
                .resizable()
                .aspectRatio(contentMode: .fit)
            
            HStack(alignment: .bottom){
                VStack(alignment:.leading) {
                    Text("Kot")
                    Text("Nieznany autor")
                }
                Spacer()
            }
            .padding()
                .foregroundColor(.green)
                .background(Color.primary.colorInvert().opacity(0.6))
                .border(Color.blue)
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}






































//
//  ContentView.swift
//  zdjeciePK
//
//  Created by student on 10/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

//import SwiftUI
//
//struct ContentView: View {
//    var body: some View {
//        ZStack(alignment: .bottom){
//        Image("kot")
//            .resizable()
//            .aspectRatio(contentMode: .fit)
//
//            HStack(alignment: .bottom){
//                VStack(alignment:.leading) {
//                    Text("Kot")
//                    Text("Smutno mi Boże")
//                }
//                Spacer()
//
//
//            }
//        .padding()
//            .foregroundColor(.orange)
//            .background(Color.primary.colorInvert().opacity(0.6))
//            .border(Color.blue)
//
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
