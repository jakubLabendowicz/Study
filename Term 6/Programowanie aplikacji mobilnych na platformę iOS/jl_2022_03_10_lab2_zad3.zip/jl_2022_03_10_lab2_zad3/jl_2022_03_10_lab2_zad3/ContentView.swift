//
//  ContentView.swift
//  jl_2022_03_10_lab2_zad3
//
//  Created by student on 10/03/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI
func czyTrojkat(b1: Int, b2: Int, b3: Int) -> String {
    if b1+b2>b3 && b1+b3>b2 && b2+b3>b1
    {
        return "Da się zbudować trójkąt"
    }
    else {return "Nie da się zbudować trójkąta"}
}

struct ContentView: View {
    @State var b1:Int = 0
    @State var b2:Int = 0
    @State var b3:Int = 0
    @State var wynik:String = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20){
            HStack{
                Text("Podaj bok 1: ")
                TextField("bok 1", text: Binding(
                    get:{String(self.b1)},
                    set: {self.b1 = Int($0) ?? 0}
                ))
                    .border(Color.black)
                    .fixedSize(horizontal: (30 != 0), vertical: true)
            }
            
            HStack{
                Text("Podaj bok 2: ")
                TextField("bok2", text: Binding(
                    get:{String(self.b2)},
                    set: {self.b2 = Int($0) ?? 0}
                ))
                    .border(Color.black)
                    .fixedSize(horizontal: (30 != 0), vertical: true)
            }
            
            HStack{
                Text("Podaj bok 3: ")
                TextField("bok 3", text: Binding(
                    get:{String(self.b3)},
                    set: {self.b3 = Int($0) ?? 0}
                ))
                    .border(Color.black)
                    .fixedSize(horizontal: (30 != 0), vertical: true)
            }
            
            HStack{
                Text("Podano: \(self.b1), \(self.b2), \(self.b3)")
            }
            
            HStack{
                Button(
                    action: {self.wynik = czyTrojkat(b1: self.b1, b2: self.b2, b3: self.b3)},
                    label: {Text("Trojkat")}
                )
                    .background(Color.blue)
                    .foregroundColor(.red)
                    .clipShape(Capsule())
            }
            
            HStack{
                Text("\(self.wynik)")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
