//
//  ContentView.swift
//  Lab9
//
//  Created by student on 05/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @GestureState var isLong = false
    @State private var location : CGPoint = CGPoint(x: 50, y: 50)
    
    @State var dog : Int = 0
    var tab = ["Dog", "Dog2"]
    var body: some View {
        
        return Circle()
        .fill(Color.red)
        .position(location)
        .gesture(DragGesture()
                .onChanged{vale in self.location = vale.location
        })
    
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
