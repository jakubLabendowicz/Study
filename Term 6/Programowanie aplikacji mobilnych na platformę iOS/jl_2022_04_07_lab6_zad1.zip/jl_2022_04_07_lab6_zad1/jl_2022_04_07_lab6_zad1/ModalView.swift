//
//  ModalView.swift
//  jl_2022_04_07_lab6_zad1
//
//  Created by student on 07/04/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ModalView: View {
    @Binding var color: Color
    @Environment (\.presentationMode) var presentationMode
    var body: some View {
        VStack {
            Picker("Select color", selection: $color) {
                Text("Red").tag(Color.red)
                Text("Green").tag(Color.green)
                Text("Blue").tag(Color.blue)
                Text("Yellow").tag(Color.yellow)
            }
            Button("Close") {
                self.presentationMode.wrappedValue.dismiss()
            }
        }
    }
}

struct ModalView_Previews: PreviewProvider {
    static var previews: some View {
        ModalView(color: .constant(Color.red))
    }
}
