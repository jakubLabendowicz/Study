//
//  ContentView.swift
//  jl_2022_04_07_lab6_zad1
//
//  Created by student on 07/04/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var showModal: Bool = false
    @State var color:Color = Color.red
    
    var body: some View {
        VStack{
            Text("Hello world!")
                .foregroundColor(color)
            
            Button(action: {
                self.showModal.toggle()
            }, label: {
                Text("Select color")
            })
                .sheet(isPresented: $showModal) {
                    ModalView(color: self.$color)
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
