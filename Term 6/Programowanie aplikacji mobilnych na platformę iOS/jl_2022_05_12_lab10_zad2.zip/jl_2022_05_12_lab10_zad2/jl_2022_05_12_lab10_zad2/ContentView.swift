//
//  ContentView.swift
//  jl_2022_05_12_lab10_zad1
//
//  Created by student on 12/05/2022.
//  Copyright © 2022 PL. All rights reserved.
//

import SwiftUI
import MapKit

class MyAnnotation: NSObject, MKAnnotation {
    let title: String?
    let subtitle: String?
    let coordinate: CLLocationCoordinate2D
    init(title: String?,
    subtitle: String?,
    coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.subtitle = subtitle
        self.coordinate = coordinate
    }
}

struct MapView: UIViewRepresentable{
    @Binding var myAnnotations : [MyAnnotation]
    @Binding var myAnnotation : MyAnnotation

    func makeUIView(context: Context) -> MKMapView {
        let myMap = MKMapView(frame: .zero)
        return myMap
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: myAnnotation.coordinate, span: span)
        uiView.setRegion(region, animated: true)
        uiView.addAnnotations(myAnnotations)
    }
}

struct ContentView: View {
    @State var myAnnotations: [MyAnnotation] = [
        MyAnnotation(
            title: "Katedra Informatyki",
            subtitle: "Politechnika Lubelska",
            coordinate: CLLocationCoordinate2D(
                latitude:51.2353112433304,
                longitude: 22.55289822681853))]
    @State var myAnnotation: MyAnnotation = MyAnnotation(
        title: "Katedra Informatyki",
        subtitle: "Politechnika Lubelska",
        coordinate: CLLocationCoordinate2D(
            latitude:51.2353112433304,
            longitude: 22.55289822681853))
    
    @State var title: String
    @State var subtitle: String
    @State var latitude: String
    @State var longitude: String

    var body: some View {
        VStack{
            MapView(myAnnotations: $myAnnotations, myAnnotation: $myAnnotation)
                .frame(
                    width: 300,
                    height: 400,
                    alignment: .center)
            TextField("Tytuł", text: $title)
                .frame(
                    width: 300,
                    height: 50,
                    alignment: .center)
            TextField("Podytuł", text: $subtitle)
                .frame(
                    width: 300,
                    height: 50,
                    alignment: .center)
            TextField("Szerokość geograficzna", text: $latitude)
                .frame(
                    width: 300,
                    height: 50,
                    alignment: .center)
                TextField("Długość geograficzna", text: $longitude)
                .frame(
                    width: 300,
                    height: 50,
                    alignment: .center)
            Button(
                "Dodaj punkt",
                action: {self.addAnnotation()})
        }
    }

    private func addAnnotation(){
        self.myAnnotations.append(
            MyAnnotation(
                title: self.title,
                subtitle: self.subtitle,
                coordinate: CLLocationCoordinate2D(
                    latitude: CLLocationDegrees(self.latitude)!,
                    longitude: CLLocationDegrees(self.longitude)!))
        )
        
        self.myAnnotation = MyAnnotation(
            title: self.title,
            subtitle: self.subtitle,
            coordinate: CLLocationCoordinate2D(
                latitude: CLLocationDegrees(self.latitude)!,
                longitude: CLLocationDegrees(self.longitude)!))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(
            title: "Brama Krakowska",
            subtitle: "Lublin",
            latitude: "51.24775457385513",
            longitude: "22.56658679983392")
    }
}
