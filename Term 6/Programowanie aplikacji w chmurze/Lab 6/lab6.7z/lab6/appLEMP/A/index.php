<!DOCTYPE html>
<html>
    <head>
        <title>Serwer docker!</title>
    </head>
    <body>
        <h1>Strona glowna</h1>
        <div>
            Autor: Rafał Maciąg<br />
            92935, GL 6.5
        </div>
    </body>
</html>
