<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="public/css/style.css">
        <link rel="stylesheet" href="public/css/section.css">
        <link rel="stylesheet" href="public/css/bar__section.css">
        <link rel="stylesheet" href="public/css/search__section.css">
        <link rel="stylesheet" href="public/css/actions__section.css">
        <link rel="stylesheet" href="public/css/tracks__section.css">
        <link rel="shortcut icon" href="public/assets/logo.png">
        <title>Searchify! - Results</title>
    </head>
    <body>
        <nav class="f__nav">
            <section class="f__section">
                <div class="f__section_inner">
                    <div class="f__bar_section">
                        <div class="f__bar_section__box">
                            <div class="f__bar_section__title">
                            <a href="index.php" class="f__bar_section__title_inner">Searchify!</a>
                            </div>
                        </div>
                        <div class="f__bar_section__box">
                            <div class="f__bar_section__element">
                                <a href="index.php" class="f__bar_section__element_inner f__bar_section__element-active">Search</a>
                            </div>
                            <div class="f__bar_section__element">
                                <a href="favorites.php" class="f__bar_section__element_inner">Favorites</a>
                            </div>
                            <div class="f__bar_section__element">
                                <div class="f__bar_section__element_inner">
                                    <div id="THEME_BUTTON" onclick="themeController.toogleState()"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </nav>
        <div class="f__container">
            <main class="f__main">
                <section class="f__section f__section-paddingtb">
                    <div class="f__section_inner">
                        <div class="f__section__header">
                            <div class="f__section__title">Results</div>
                            <div class="f__section__header__box">
                                <a href="export_json.json" id="FILE_DOWNLOAD"></a>
                                <a href="export_xml.xml" id="FILE_DOWNLOAD"></a>
                            </div>
                        </div>
                        <?php
                            include 'src/Track/TrackController.php';
                            $tc = new TrackController();
                            $tc->loadSearched();
                            $tc->viewTracks();
                            $tc->exportJSON();
                            $tc->exportXML();
                        ?>
                    </div>
                </section>
            </main>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="public/js/Wilga.js"></script>
        <script src="public/js/theme.js"></script>
        <script src="public/js/favorite.js"></script>
    </body>
</html>