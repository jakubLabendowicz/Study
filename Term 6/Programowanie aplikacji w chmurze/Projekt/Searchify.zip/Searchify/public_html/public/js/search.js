function search() {
    var value = document.getElementById('SEARCH_INPUT').value;
    window.open("results.php", "_self");
    document.cookie = "q="+value;
}