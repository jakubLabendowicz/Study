var lightTheme = new State("light_theme");
lightTheme.addProperty("--MAIN_BACKGROUND_COLOR", "#ffffff");
lightTheme.addProperty("--MAIN_TEXT_COLOR", "#000000");

lightTheme.addProperty("--ELEMENT_BACKGROUND_COLOR", "#ffffff");
lightTheme.addProperty("--ELEMENT_TEXT_COLOR", "#000000");
lightTheme.addProperty("--ELEMENT_SHADOW_COLOR", "#D6D6D6");

lightTheme.addProperty("--ICON_COLOR_INVERT", "0%");

// lightTheme.addProperty("--THEME_ICON", "../assets/icons/light_mode_FILL0_wght400_GRAD0_opsz48.svg");

var darkTheme = new State("dark_theme");
darkTheme.addProperty("--MAIN_BACKGROUND_COLOR", "#101010");
darkTheme.addProperty("--MAIN_TEXT_COLOR", "#ffffff");

darkTheme.addProperty("--ELEMENT_BACKGROUND_COLOR", "#000000");
darkTheme.addProperty("--ELEMENT_TEXT_COLOR", "#ffffff");
darkTheme.addProperty("--ELEMENT_SHADOW_COLOR", "#00000000");

darkTheme.addProperty("--ICON_COLOR_INVERT", "100%");

// darkTheme.addProperty("--THEME_ICON", 'url("../assets/icons/dark_mode_FILL0_wght400_GRAD0_opsz48.svg")');

var themeController = new StateController("theme_controller");
themeController.addState(lightTheme);
themeController.addState(darkTheme);
themeController.setFirstState(0);
themeController.run();
