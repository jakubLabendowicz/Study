function setFavorite(id, name, artists, spotifyId, favorite, previewUrl, popularity, durationMs, image) {
    var track = {
        "id": id,
        "name": name,
        "artists": artists,
        "spotifyId": spotifyId,
        "favorite": favorite,
        "previewUrl": previewUrl,
        "popularity": popularity,
        "durationMs": durationMs,
        "image": image
    }
    console.log(track);

    $.ajax({
        type: "POST",
        url: "setFavorite.php",
        data: track, 
        success: function(){
            // alert(proj_name + ' ' + status);
            // window.open("test.php"); 
        },
        error: function (xhr, ajaxOptions, thrownError){
            alert(xhr.status);
            alert(thrownError);
        }
    });

    // document.cookie = "setFavoriteSpotifyId="+spotifyId;

    var element = document.getElementsByName(spotifyId)[0];
    if(element.id == "FAVORITE_FALSE") {
        element.id = "FAVORITE_TRUE";
    } else if(element.id == "FAVORITE_TRUE") {
        element.id = "FAVORITE_FALSE";
    }
}