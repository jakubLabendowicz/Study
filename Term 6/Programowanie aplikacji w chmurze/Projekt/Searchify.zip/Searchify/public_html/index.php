<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="public/css/style.css">
        <link rel="stylesheet" href="public/css/section.css">
        <link rel="stylesheet" href="public/css/bar__section.css">
        <link rel="stylesheet" href="public/css/search__section.css">
        <link rel="stylesheet" href="public/css/actions__section.css">
        <link rel="stylesheet" href="public/css/tracks__section.css">
        <link rel="shortcut icon" href="public/assets/logo.png">
        <title>Searchify!</title>
    </head>
    <body>
        <nav class="f__nav">
            <section class="f__section">
                <div class="f__section_inner">
                    <div class="f__bar_section">
                        <div class="f__bar_section__box">
                            <div class="f__bar_section__title">
                                <a href="index.php" class="f__bar_section__title_inner">Searchify!</a>
                            </div>
                        </div>
                        <div class="f__bar_section__box">
                            <div class="f__bar_section__element">
                                <a href="index.php" class="f__bar_section__element_inner f__bar_section__element-active">Search</a>
                            </div>
                            <div class="f__bar_section__element">
                                <a href="favorites.php" class="f__bar_section__element_inner">Favorites</a>
                            </div>
                            <div class="f__bar_section__element">
                                <div class="f__bar_section__element_inner">
                                    <div id="THEME_BUTTON" onclick="themeController.toogleState()"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </nav>
        <div class="f__container">
            <header class="f__header">
                <section class="f__section" style="height: calc(100vh - 200px);">
                    <div class="f__section_inner">
                        <div class="f__section__title">Searchify!</div>
                        <div class="f__search_section__bar">
                            <input id="SEARCH_INPUT" class="f__search_section__bar__input" type="text" placeholder="Search your track"></input>
                            <button class="f__search_section__bar__button" onclick="search()">
                                <div id="SEARCH"></div>
                            </button>
                        </div>
                    </div>
                </section>
            </header>
        </div>
        <script src="public/js/Wilga.js"></script>
        <script src="public/js/theme.js"></script>
        <script src="public/js/search.js"></script>
    </body>
</html>