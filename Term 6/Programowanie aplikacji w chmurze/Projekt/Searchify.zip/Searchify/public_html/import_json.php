<?php
    include 'src/Track/TrackController.php';
    (new TrackController)->importJSON();
?>