<?php
class TrackCallouts {
  // Properties
  public $api;

  // Methods
  function setAPI($api) {
    $this->api = $api;
  }

  function searchTracks($q) {
    $results = $this->api->search($q, 'track');
    $tracks = array();
    foreach ($results->tracks->items as $item) {
        $track = (new TrackBuilder())
        ->withName($item->name)
        ->withArtists($item->artists[0]->name)
        ->withSpotifyId($item->id)
        ->withFavorite(0)
        ->withPreviewUrl($item->preview_url)
        ->withPopularity($item->popularity)
        ->withDurationMs($item->duration_ms)
        ->withImage($item->album->images[0]->url)
        ->build();
        array_push($tracks, $track);
    }
    return $tracks;
  }
}
