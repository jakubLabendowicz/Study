<?php
    include 'TrackService.php';
    include 'TrackUtils.php';

    class TrackController {
        public $tracks;

        function loadSearched() {
            if (isset($_COOKIE['q'])) {
                $q = $_COOKIE['q'];
            } else {
                $q = 'The River';
            }
            $trackService = new TrackService();
            $this->tracks = $trackService->searchTracks($q);
        }

        function loadFavorites() {
            $trackService = new TrackService();
            $this->tracks = $trackService->getFavoriteTracks();
        }

        function viewTracks() {
            foreach ($this->tracks as $item) {
                echo '
                <div class="f__tracks_section__element" data-id="'.$item->id.'" data-spotifyId="'.$item->spotifyId.'" data-name="'.$item->name.'">
                    <div class="f__tracks_section__element__box">
                        <div class="f__tracks_section__element__icon">
                            <img src="'.$item->image.'" style="width:50px; height:50px; border-radius: 5px;" class="f__tracks_section__element__icon__inner"></img>
                        </div>
                        <div class="f__tracks_section__element__info">
                            <a href="https://open.spotify.com/track/',$item->spotifyId,'" class="f__tracks_section__element__title">',$item->name,'</a>
                            <div class="f__tracks_section__element__subtitle">',$item->artists,'</div>
                        </div>
                    </div>
                    <div class="f__tracks_section__element__actions__box">';
                    if(isset($item->previewUrl)) {
                        echo '
                        <a href="',$item->previewUrl,'" class="f__tracks_section__element__action">
                            <div class="f__tracks_section__element__action__inner" id="PLAY"></div>
                        </a>
                        ';
                    }
                 echo '
                        <a href="https://open.spotify.com/track/',$item->spotifyId,'" class="f__tracks_section__element__action">
                            <div class="f__tracks_section__element__action__inner" id="OPEN"></div>
                        </a>';
                        if(isset($item->favorite) && $item->favorite == false) {
                            echo '
                            <div class="f__tracks_section__element__action" onClick=\'setFavorite(',(new TrackUtils())->getParamsStringFromObject($item),')\'>
                                <div class="f__tracks_section__element__action__inner" name="',$item->spotifyId,'" id="FAVORITE_FALSE"></div>
                            </div>
                            ';
                        }
                        if(isset($item->favorite) && $item->favorite == true) {
                            echo '
                            <div class="f__tracks_section__element__action" onClick=\'setFavorite(',(new TrackUtils())->getParamsStringFromObject($item),')\'>
                                <div class="f__tracks_section__element__action__inner" name="',$item->spotifyId,'" id="FAVORITE_TRUE"></div>
                            </div>
                            ';
                        }
                echo '
                    </div>
                </div>';
            }
        }

        function exportJSON() {
            if(count($this->tracks) != 0) {
                $json = (new TrackUtils)->getJSONFromObjectsList($this->tracks);
                file_put_contents("export_json.json", $json);
            }   
        }
        
        function exportXML() {
            if(count($this->tracks) != 0) {
                $json = (new TrackUtils)->getJSONFromObjectsList($this->tracks);
                $array = json_decode($json);
                $xml = (new TrackUtils)->getXMLFromObjectsList($array[0], '<track/>');
                file_put_contents("export_xml.xml", $xml);
            }
        }

        function importJSON() {
            $json = file_get_contents("import_json.json");
            if(isset($json)) {
                $list = (new TrackUtils)->getObjectsListFromJSON($json);
                foreach ($list as $item) {
                    print_r($item);
                    echo '<br><br>';
                    $trackService = new TrackService();
                    $item = $trackService->setFavorite($item);
                }
            }   
        }

        function importXML() {
            $xml = file_get_contents("import_xml.xml");
            if(isset($xml)) {
                $list = (new TrackUtils)->getObjectsListFromXML($xml);
                // foreach ($list as $item) {
                    print_r($list);
                    echo '<br><br>';
                    $trackService = new TrackService();
                    $item = $trackService->setFavorite($list);
                // }
            }   
        }

        function setFavorite() {
            $track = (new TrackBuilder())
            ->withId($_POST['id'])
            ->withName($_POST['name'])
            ->withArtists($_POST['artists'])
            ->withSpotifyId($_POST['spotifyId'])
            ->withFavorite($_POST['favorite'])
            ->withPreviewUrl($_POST['previewUrl'])
            ->withPopularity($_POST['popularity'])
            ->withDurationMs($_POST['durationMs'])
            ->withImage($_POST['image'])
            ->build();

            $trackService = new TrackService();
            $track = $trackService->setFavorite($track);
        }
    }
?>