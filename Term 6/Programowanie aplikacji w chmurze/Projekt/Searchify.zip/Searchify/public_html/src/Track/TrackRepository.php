<?php
class TrackRepository {
  // Properties
  public $db;

  // Methods
  function setDB($db) {
    $this->db = $db;
  }

  function insertTrack($track) {
    if (isset($track->previewUrl) && isset($track->image)) {
      $this->db->query('INSERT INTO tracks (name,artists,spotifyId,favorite,previewUrl,popularity,durationMs,image) 
                        VALUES (?,?,?,?,?,?,?,?)', $track->name, $track->artists, $track->spotifyId, $track->favorite, $track->previewUrl, $track->popularity, $track->durationMs, $track->image);
    } else if(isset($track->previewUrl)) {
      $this->db->query('INSERT INTO tracks (name,artists,spotifyId,favorite,previewUrl,popularity,durationMs) 
                        VALUES (?,?,?,?,?,?,?)', $track->name, $track->artists, $track->spotifyId, $track->favorite, $track->previewUrl, $track->popularity, $track->durationMs);
    } else if (isset($track->image)) {
      $this->db->query('INSERT INTO tracks (name,artists,spotifyId,favorite,popularity,durationMs,image) 
                        VALUES (?,?,?,?,?,?,?)', $track->name, $track->artists, $track->spotifyId, $track->favorite, $track->popularity, $track->durationMs, $track->image);
    }
    $track->id = $this->db->lastInsertID();
    return $track;
  }

  function updateTrack($track) {
    $this->db->query('UPDATE tracks
                      SET favorite = '.$track->favorite.' WHERE id = "'.$track->id.'"');
    return $track;
  }

  function selectTracks() {
    $results = $this->db->query('SELECT * FROM tracks')->fetchAll();
    $tracks = array();
    foreach ($results as $item) {
        $track = (new TrackBuilder())->fromArray($item)->build();
        array_push($tracks, $track);
    }
    return $tracks;
  }

  function selectFavoriteTracks() {
    $results = $this->db->query('SELECT * FROM tracks WHERE favorite = true')->fetchAll();
    $tracks = array();
    foreach ($results as $item) {
        $track = (new TrackBuilder())->fromArray($item)->build();
        array_push($tracks, $track);
    }
    return $tracks;
  }
}
?>