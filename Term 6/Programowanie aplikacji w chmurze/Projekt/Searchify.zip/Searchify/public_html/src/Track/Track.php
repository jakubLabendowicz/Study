<?php
class Track {
  // Properties
  public $id;

  public $name;
  public $artists;
  public $spotifyId;
  public $favorite;

  public $previewUrl;
  public $popularity;
  public $durationMs;
  public $image;
}
