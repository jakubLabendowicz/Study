<?php
//model
include 'Track.php';
include 'TrackBuilder.php';

//repository
include 'src/db.php';
include 'src/Track/TrackRepository.php';

//callouts
include 'src/SpotifyWebAPI.php';
include 'src/Session.php';
include 'src/Track/TrackCallouts.php';

class TrackService
{
    // Methods
    function searchTracks($q)
    {
        $session = new SpotifyWebAPI\Session(
            '95fc4b149fdf4874b4bdfa4aaf926bf0',
            '048746e1fb794ef5b74f2f825dac4022',
            'http://localhost/Searchify/results.php'
        );

        $api = new SpotifyWebAPI\SpotifyWebAPI();

        if (isset($_GET['code'])) {
            $session->requestAccessToken($_GET['code']);
            $api->setAccessToken($session->getAccessToken());

            $tc = new TrackCallouts();
            $tc->setAPI($api);
            $searchedTracks = $tc->searchTracks($q);
            $dbTracks = $this->getTracks();
            $newList = array();
            foreach($searchedTracks as $item) {
                $track = (new TrackUtils())->getObjectFromListByspotifyId($dbTracks, $item->spotifyId);
                if(isset($track->spotifyId)) {
                    $item->favorite = $track->favorite;
                    $item->id = $track->id;
                }
                array_push($newList, $item);
            }
            return $newList;
        } else {
            $options = [
                'scope' => [
                    'user-read-email',
                ],
            ];

            header('Location: ' . $session->getAuthorizeUrl($options));
            die();
        }
    }

    function getTracks()
    {
        $dbhost = 'db';
        $dbuser = 'user';
        $dbpass = 'pass';
        $dbname = 'searchify';

        $db = new db($dbhost, $dbuser, $dbpass, $dbname);

        $tr = new TrackRepository();
        $tr->setDB($db);
        return $tr->selectTracks();
        $db->close();
    }

    function getFavoriteTracks()
    {
        $dbhost = 'db';
        $dbuser = 'user';
        $dbpass = 'pass';
        $dbname = 'searchify';

        $db = new db($dbhost, $dbuser, $dbpass, $dbname);

        $tr = new TrackRepository();
        $tr->setDB($db);
        return $tr->selectFavoriteTracks();
        $db->close();
    }

    function setFavorite($track)
    {
        $dbhost = 'db';
        $dbuser = 'user';
        $dbpass = 'pass';
        $dbname = 'searchify';

        $db = new db($dbhost, $dbuser, $dbpass, $dbname);

        $tr = new TrackRepository();
        $tr->setDB($db);
        if ($track->favorite == 0) {
            $track->favorite = 1;
        } else if ($track->favorite == 1) {
            $track->favorite = 0;
        }
        if(isset($track->id)) {
            $track = $tr->updateTrack($track);
        } else {
            $track = $tr->insertTrack($track);
        }
        return $track;
        $db->close();
    }
}
?>