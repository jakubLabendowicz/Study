<?php
class TrackUtils {
    function getObjectFromListByspotifyId($list, $spotifyId)
    {
        foreach ($list as $item) {
            if(isset($item->spotifyId)) {
                if($item->spotifyId == $spotifyId) {
                    return $item;
                }
            }
        }
        return new Track();
    }

    function getParamsStringFromObject($track)
    {
        if (isset($track->id)) {
            $id = $track->id;
        } else {
            $id = "undefined";
        }
        return $id. ', "' .$track->name. '", "' .$track->artists. '", "' .$track->spotifyId. '", ' .$track->favorite. ', "' .$track->previewUrl. '", ' .$track->popularity. ', ' .$track->durationMs. ', "' .$track->image.'"';
    }

    function getJSONFromObjectsList($list)
    {
        return json_encode($list);
    }

    function getXMLFromObjectsList($array, $rootElement = null, $xml = null)
    {
        $_xml = $xml;
          
        // If there is no Root Element then insert root
        if ($_xml === null) {
            $_xml = new SimpleXMLElement($rootElement !== null ? $rootElement : '<track/>');
        }
          
        // Visit all key value pair
        foreach ($array as $k => $v) {
              
            // If there is nested array then
            if (is_array($v)) { 
                  
                // Call function for nested array
                (new TrackUtils)->getXMLFromObjectsList($v, $k, $_xml->addChild($k));
                }
                  
            else {
                  
                // Simply add child element. 
                $_xml->addChild($k, $v);
            }
        }
          
        return $_xml->asXML();
    }

    function getObjectsListFromJSON($json)
    {
        $results = json_decode($json);
        return $results;
    }

    function getObjectsListFromXML($xml_string)
    {
        $xml = simplexml_load_string($xml_string);
        $json = json_encode($xml);
        $results = json_decode($json);
        return $results;
    }
}
