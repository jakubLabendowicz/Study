<?php 
class TrackBuilder {

    public $id;

    public $name;
    public $artists;
    public $spotifyId;
    public $favorite;

    public $previewUrl;
    public $popularity;
    public $durationMs;
    public $image;
 
    public function withId($id){
        $this->id = $id;
        return $this;
    }

    public function withName($name){
        $this->name = $name;
        return $this;
    }

    public function withArtists($artists){
        $this->artists = $artists;
        return $this;
    }

    public function withSpotifyId($spotifyId){
        $this->spotifyId = $spotifyId;
        return $this;
    }

    public function withFavorite($favorite){
        $this->favorite = $favorite;
        return $this;
    }

    public function withPreviewUrl($previewUrl){
        $this->previewUrl = $previewUrl;
        return $this;
    }

    public function withPopularity($popularity){
        $this->popularity = $popularity;
        return $this;
    }

    public function withDurationMs($durationMs){
        $this->durationMs = $durationMs;
        return $this;
    }

    public function withImage($image){
        $this->image = $image;
        return $this;
    }

    public function fromArray($item){
        $this->id = $item['id'];

        $this->name = $item['name'];
        $this->artists = $item['artists'];
        $this->spotifyId = $item['spotifyId'];
        $this->favorite = $item['favorite'];

        $this->previewUrl = $item['previewUrl'];
        $this->popularity = $item['popularity'];
        $this->durationMs = $item['durationMs'];
        $this->image = $item['image'];
        return $this;
    }

    public function build():Track {
        $track = new Track();
        $track->id = $this->id;

        $track->name = $this->name;
        $track->artists = $this->artists;
        $track->spotifyId = $this->spotifyId;
        $track->favorite = $this->favorite;

        $track->previewUrl = $this->previewUrl;
        $track->popularity = $this->popularity;
        $track->durationMs = $this->durationMs;
        $track->image = $this->image;
        return $track;
    }

}
