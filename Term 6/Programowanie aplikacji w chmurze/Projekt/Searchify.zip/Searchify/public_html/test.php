<h1>Testowa strona</h1>
<?php
    $dbhost = 'db';
    $dbuser = 'MYSQL_USER';
    $dbpass = 'MYSQL_PASSWORD';
    $dbname = 'searchify';

    $conn = new mysqli($dbhost, $dbuser, $dbpass);

    if($conn->connection_error) {
        die("Nie udało się połączyć z bazą danych: " . $conn->connection_error);
    }

    echo "Połączono z bazą danych";
?>