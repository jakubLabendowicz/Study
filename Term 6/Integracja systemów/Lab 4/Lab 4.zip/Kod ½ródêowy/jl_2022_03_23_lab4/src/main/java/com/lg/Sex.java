package com.lg;

public class Sex {
    public enum SexEnum {
        MALE, FEMALE;
    }
}
